#!/usr/bin/python3
# -*- coding: UTF-8 -*-
import requests
from tkinter import *
def call():
    appele=appele1.get()
    appelant=appelant1.get()
    para="PJSIP/"+appelant
    params = (('endpoint', para),('extension', appele),('context', 'rtn'),('priority', '1'),('callerId', appelant),)
    response = requests.post('http://192.168.1.11:8088/ari/channels',params=params, auth=('asterisk', 'passer'))


root = Tk()
root.title("Mise en communication Avec Tkinter ")
root.geometry("400x500")
root.resizable(width=FALSE, height=FALSE)
labelappelant=Label(root,text="Appelant")
labelappele=Label(root,text="Appele")
appelant1=StringVar()
appele1=StringVar()
entreeappelant=Entry(root,textvariable=appelant1)
entreeappele=Entry(root, textvariable=appele1)
labelappelant.place(x=6,y=6,width="110",height=50)
labelappele.place(x=6,y=56,width="110",height=50)
entreeappelant.place(x=116,y=6, width="110", height=50)
entreeappele.place(x=116,y=56, width="110", height="50")
bouton= Button(root, text="Send", width="10", height=5,bd=0, bg="#0080ff",
activebackground="#00bfff",foreground='#ffffff',font=("Arial", 12),command= call)
bouton.place(x=6, y=400, height=88)
root.mainloop()
