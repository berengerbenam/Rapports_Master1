#!/usr/bin/python3
# -*- coding: UTF-8 -*-
import cgi, cgitb
import requests
def call(appelant,appele):
    para="PJSIP/"+appelant
    params = (('endpoint', para),('extension', appele),('context', 'rtn'),('priority', '1'),('callerId', appelant),)
    response = requests.post('http://192.168.1.11:8088/ari/channels',params=params, auth=('asterisk', 'passer'))


print("Content-Type: text/html")
print()
print("<html><head><title>MISE EN CONYACT</title></head>")
print("<body>")
form = cgi.FieldStorage()
appelant = form.getvalue('appelant')
appele = form.getvalue('appele')
call(appelant,appele)
print("users mis en communication")
print("</body>")
print("</html>")

