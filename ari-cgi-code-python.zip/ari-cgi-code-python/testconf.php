<?php
$typeconf=$_REQUEST['typeconf'];
$nomconf=$_REQUEST['nomconf'];
$ch=curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8088/ari/bridges/'.$nomconf.'?type='.$typeconf.'&name='.$nomconf.'&api_key=asterisk:passer');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');

$response = curl_exec($ch);
curl_close($ch);



?>
